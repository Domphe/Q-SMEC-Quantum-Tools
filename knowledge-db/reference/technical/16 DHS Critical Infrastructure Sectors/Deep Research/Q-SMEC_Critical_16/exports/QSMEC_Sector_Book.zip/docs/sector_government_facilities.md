# Government Facilities — Q-SMEC Application Playbook

## 1. Problem → Failure Mechanism
- Problem statements
- Classical sensor limits

## 2. Q-SMEC Fit
- Replacement class
- Expected mitigations
- Deployment loci

## 3. Evidence
- Datasets table with URL, retrieval date, license, metric

## 4. Engineering & Ops
- SWaP-C budget
- Control & SCADA integration
- Cybersecurity & anti-tamper

## 5. Regulatory & Compliance
- Relevant frameworks and requirements

## 6. Licensing Path
- Task 4+ artifacts list
