import os
os.system("streamlit run cli/run_dashboard.py")