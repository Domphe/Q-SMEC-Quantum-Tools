from utils.ml_utils import train_quantum_model
train_quantum_model("data/benchmarks/benchmark_dataset.json")