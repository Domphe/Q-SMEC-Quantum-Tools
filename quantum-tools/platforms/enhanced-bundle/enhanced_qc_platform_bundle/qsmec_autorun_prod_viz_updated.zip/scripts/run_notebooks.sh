#!/bin/bash
jupyter nbconvert --to notebook --execute notebooks/*.ipynb --output executed_notebook.ipynb
