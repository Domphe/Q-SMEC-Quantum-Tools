
#!/bin/bash
jupyter nbconvert --to notebook --execute notebooks/train_model.ipynb --output notebooks/output_train.ipynb
